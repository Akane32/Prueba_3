document.addEventListener("DOMContentLoaded", function() {
    const contactInfo = {
        nombreApellido: "Juan Pérez",
        profesion: "Estudiante de Ingeniería Informática",
        correo: "juanperez@example.com",
        telefono: "123-456-7890",
        resumenLaboral: "Experiencia en desarrollo web y programación."
    };

    const contactInfoDiv = document.getElementById("contactInfo");
    for (const [key, value] of Object.entries(contactInfo)) {
        const p = document.createElement("p");
        if (key === 'nombreApellido') {
            const nombreYApellido = value.split(" ");
            p.textContent = `${key}: ${nombreYApellido[0]} ${nombreYApellido[1]}`;
        } else {
            p.textContent = `${key}: ${value}`;
        }
        contactInfoDiv.appendChild(p);
    }
});